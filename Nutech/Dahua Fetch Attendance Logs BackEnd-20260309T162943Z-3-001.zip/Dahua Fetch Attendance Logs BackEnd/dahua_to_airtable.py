import requests
from requests.auth import HTTPDigestAuth
from datetime import datetime, timezone, timedelta
import os
import sys
import time
import json

# =========================
# DEVICE CONFIG (Dahua - device CGI used)
# =========================
# Try each IP in order until one responds (e.g. primary + backup device)
DEVICE_IPS = ["192.168.8.119", "192.168.8.120"]
USERNAME = "admin"
PASSWORD = "nutech@0210"

# =========================
# DAHUA API ENDPOINTS
# =========================
# Task                          | CGI Endpoint
# ------------------------------|----------------------------------------------------------
# Fetch offline access logs     | /cgi-bin/recordFinder.cgi?action=find&name=AccessControlCardRec
# Add user/card                 | /cgi-bin/recordUpdater.cgi?action=insert&name=AccessControlCard
# Remote unlock                 | /cgi-bin/accessControl.cgi?action=openDoor
# Upload face template          | /cgi-bin/FaceInfoManager.cgi?action=add

# =========================
# AIRTABLE CONFIG
# =========================
AIRTABLE_BASE_ID = "appknq8ZNHR7J2hrs"
AIRTABLE_API_KEY = "patSTe5ftaRJ8hozm.3ccfdf2d71d7ca6a4da103f42f7460deed4ac2d2998e6af88ebc24e1c8c6e434"

PUSH_TO_LOGS = True
PUSH_TO_CHECK_IN = False 
PUSH_TO_CHECK_OUT = False
PUSH_TO_USERS = True

TABLE_LOGS = "Logs"
TABLE_USERS = "Users"

FIELDS_LOGS = {
    "UserID": "UserID",
    "Name": "Name",
    "Attendance Date": "Attendance Date",
    "CardNo": "CardNo",
    "Check-in Time": "Check-in Time",
    "Check-out Time": "Check-out Time",
    "Total Work Time": "Total Work Time",
    "Detection Mode": "Detection Mode",
}

FIELDS_USERS = {
    "UserID": "UserID",
    "Name": "Name",
    "CardNo": "CardNo",
}


# Detection Mode: values sent to Airtable Multiple Select.
# Dahua record fields: FaceIndex=1 -> Face; Method/VerifyType: 0=Password, 1=Card, 2=Face.
DETECTION_MODE_OPTIONS = ["Face", "Card", "Password"]

# =========================
# FILES
# =========================
RECNO_FILE = "last_recno.txt"
LOCAL_LOGS_FILE = "dahua_logs_backup.json"

# =========================
# AUTO-RUN 
# =========================
POLL_INTERVAL_MINUTES = 3

DEBUG_LOOKUP = True

try:
    from zoneinfo import ZoneInfo
except ImportError:
    ZoneInfo = None  # Python < 3.9

OFFICE_START_HOUR = 8  
OFFICE_END_HOUR = 17   
OFFICE_TZ = "Asia/Manila" 
OFFICE_TZ_FALLBACK_UTC_OFFSET_HOURS = 8

# =========================
# HELPERS
# =========================
def unix_to_iso(ts):
    """Convert Unix timestamp to ISO string for Airtable Date field."""
    try:
        return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    except (ValueError, TypeError):
        return ""


def unix_to_date_str(ts):
    """Convert Unix timestamp to date only YYYY-MM-DD."""
    try:
        return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%d")
    except (ValueError, TypeError):
        return ""

def load_last_recno():
    if not os.path.exists(RECNO_FILE):
        return 0
    with open(RECNO_FILE, "r") as f:
        try:
            return int(f.read().strip())
        except (ValueError, OSError):
            return 0

def save_last_recno(recno):
    with open(RECNO_FILE, "w") as f:
        f.write(str(recno))

def parse_dahua_response(text):
    records = {}
    for line in text.splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key.startswith("records["):
            index = key.split("[")[1].split("]")[0]
            field = key.split("].")[1]
            records.setdefault(index, {})[field] = value
    return records

# =========================
# FETCH LOGS FROM DAHUA (recordFinder.cgi)
# =========================
RECORD_NAMES_TO_TRY = ["AccessControlCardRec"]


def _fetch_record_finder(name, device_ip):
    """Fetch one record type from recordFinder.cgi (offline access logs)."""
    url = f"http://{device_ip}/cgi-bin/recordFinder.cgi"
    r = requests.get(
        url,
        params={"action": "find", "name": name},
        auth=HTTPDigestAuth(USERNAME, PASSWORD),
        timeout=15,
    )
    r.raise_for_status()
    return r.text


def fetch_logs():
    """Fetch offline access logs. Tries each DEVICE_IPS, then RECORD_NAMES_TO_TRY; returns first successful response."""
    last_err = None
    for device_ip in DEVICE_IPS:
        for name in RECORD_NAMES_TO_TRY:
            try:
                text = _fetch_record_finder(name, device_ip)
                print(f"Fetched logs from device {device_ip}")
                return text
            except Exception as e:
                last_err = e
                continue
    if last_err:
        raise last_err
    raise RuntimeError("No device in DEVICE_IPS and no record type in RECORD_NAMES_TO_TRY succeeded")


# =========================
# PUSH TO AIRTABLE
# =========================
def to_int(val):
    """Convert to int for Airtable Number fields. Returns None if empty/invalid."""
    if val is None or val == "":
        return None
    try:
        return int(val)
    except (ValueError, TypeError):
        return None


def push_to_table(table_name, fields_dict, base_id=None):
    """Push one record to an Airtable table. Raises on error."""
    base_id = base_id or AIRTABLE_BASE_ID
    url = f"https://api.airtable.com/v0/{base_id}/{table_name}"
    headers = {
        "Authorization": f"Bearer {AIRTABLE_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {"records": [{"fields": fields_dict}]}
    r = requests.post(url, json=payload, headers=headers, timeout=30)
    if not r.ok:
        print(f"Airtable error ({table_name}):", r.status_code, r.text)
        if r.status_code == 422:
            print("--> Check that column names match your Airtable table exactly.")
    r.raise_for_status()


def user_exists_in_users_table(user_id, card_no):
    """Return True if a user row already exists in Users table (by UserID or CardNo)."""
    url = f"https://api.airtable.com/v0/{AIRTABLE_BASE_ID}/{TABLE_USERS}"
    headers = {
        "Authorization": f"Bearer {AIRTABLE_API_KEY}",
    }
    # Prefer matching by UserID when present; otherwise fall back to CardNo.
    if user_id not in (None, 0):
        formula = f"{{UserID}} = {int(user_id)}"
    elif card_no:
        escaped = str(card_no).replace("'", "\\'")
        formula = f"{{CardNo}} = '{escaped}'"
    else:
        return False

    params = {"filterByFormula": formula, "maxRecords": 1}
    try:
        resp = requests.get(url, headers=headers, params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        return bool(data.get("records"))
    except Exception as e:
        print("Warning: could not check existing Users in Airtable:", e)
        return False


def _parse_iso_datetime(value: str):
    """Parse ISO datetime from Airtable/our format (handles trailing Z)."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def _format_iso_datetime(dt: datetime):
    """Format datetime as ISO string Airtable-friendly (UTC)."""
    if dt is None:
        return ""
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def _find_logs_record(user_id, date_str, card_no=None, name=None):
    """Find existing Logs row for (UserID, Attendance Date). One row per user per day; we update it, never create a second."""
    url = f"https://api.airtable.com/v0/{AIRTABLE_BASE_ID}/{TABLE_LOGS}"
    headers = {"Authorization": f"Bearer {AIRTABLE_API_KEY}"}
    date_part = _date_part_formula(FIELDS_LOGS["Attendance Date"], date_str)
    if user_id is not None and int(user_id) != 0:
        for formula in [
            f"AND({{{FIELDS_LOGS['UserID']}}} = {int(user_id)}, {date_part})",
            f"AND({{{FIELDS_LOGS['UserID']}}} = '{user_id}', {date_part})",
        ]:
            try:
                params = {"filterByFormula": formula, "maxRecords": 1}
                resp = requests.get(url, headers=headers, params=params, timeout=30)
                resp.raise_for_status()
                data = resp.json()
                records = data.get("records") or []
                if records:
                    return records[0]
            except Exception as e:
                if "422" not in str(e):
                    print("Warning: could not query Logs table:", e)
                continue
        return _find_record_by_user_id_then_date(TABLE_LOGS, FIELDS_LOGS, user_id, date_str)
    if card_no and str(card_no).strip():
        try:
            escaped = str(card_no).strip().replace("'", "\\'")
            formula = f"AND({{{FIELDS_LOGS['CardNo']}}} = '{escaped}', {date_part})"
            params = {"filterByFormula": formula, "maxRecords": 1}
            resp = requests.get(url, headers=headers, params=params, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            records = data.get("records") or []
            if records:
                return records[0]
        except Exception as e:
            if "422" not in str(e):
                print("Warning: could not query Logs table by CardNo:", e)
    if name and _normalize_name_for_match(name):
        return _find_check_in_record_by_name_fallback(date_str, name, TABLE_LOGS, FIELDS_LOGS)
    return None


def _normalize_name_for_match(name):
    """Lowercase and collapse multiple spaces so 'Ansierina  Bautista' matches 'Ansierina Bautista'."""
    if not name or not str(name).strip():
        return ""
    return " ".join(str(name).strip().lower().split())


def _date_part_formula(field_name, date_str):
    """Compare date. Use simple equality so Airtable accepts the formula (STR/FIND can cause 422 on Date fields)."""
    return f"{{{field_name}}} = '{date_str}'"


def _find_record_by_user_id_then_date(table, fields_config, user_id, date_str):
    """Find row by UserID then filter by date in Python (avoids Airtable date formula issues)."""
    if user_id is None or int(user_id) == 0:
        return None
    url = f"https://api.airtable.com/v0/{AIRTABLE_BASE_ID}/{table}"
    headers = {"Authorization": f"Bearer {AIRTABLE_API_KEY}"}
    uid_field = fields_config["UserID"]
    date_field = fields_config["Attendance Date"]
    for formula in [f"{{{uid_field}}} = {int(user_id)}", f"{{{uid_field}}} = '{user_id}'"]:
        try:
            params = {"filterByFormula": formula, "maxRecords": 20}
            resp = requests.get(url, headers=headers, params=params, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            for rec in (data.get("records") or []):
                f = rec.get("fields") or {}
                d = f.get(date_field)
                if d is None:
                    continue
                if isinstance(d, str) and (d == date_str or d.startswith(date_str)):
                    return rec
                if str(d) == date_str or str(d).startswith(date_str):
                    return rec
            if data.get("records"):
                break 
        except Exception as e:
            print("Warning: UserID+date fallback failed:", e)
    return None


def _find_check_in_record_by_name_fallback(date_str, name, table, fields_config):
    """Fetch records for this date, then match by normalized name in Python."""
    norm = _normalize_name_for_match(name)
    if not norm:
        return None
    url = f"https://api.airtable.com/v0/{AIRTABLE_BASE_ID}/{table}"
    headers = {"Authorization": f"Bearer {AIRTABLE_API_KEY}"}
    date_field = fields_config["Attendance Date"]
    date_part = f"{{{date_field}}} = '{date_str}'"
    try:
        params = {"filterByFormula": date_part, "maxRecords": 100}
        resp = requests.get(url, headers=headers, params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        name_field = fields_config.get("Name") or "Name"
        for rec in (data.get("records") or []):
            f = rec.get("fields") or {}
            val = f.get(name_field)
            if val and _normalize_name_for_match(val) == norm:
                return rec
        return None
    except Exception as e:
        print("Warning: name fallback lookup failed:", e)
        return None


def _find_check_in_record(user_id, date_str, card_no=None, name=None):
    """Deprecated: Check-in table no longer used. Kept only to avoid breaking old imports."""
    return None


def _find_check_out_record(user_id, date_str, card_no=None, name=None):
    """Deprecated: Check-out table no longer used. Kept only to avoid breaking old imports."""
    return None


def _get_field_value(fields, preferred_key, fallback_keys_lower=None):
    """Get value from record fields. Tries preferred key, then case-insensitive match (e.g. 'check-in time')."""
    if not fields:
        return None
    val = fields.get(preferred_key)
    if val is not None and val != "":
        return val
    if fallback_keys_lower is None:
        fallback_keys_lower = (preferred_key.lower(), preferred_key.lower().replace(" ", ""), preferred_key.lower().replace("-", " "))
    for key, v in fields.items():
        if v is None or v == "":
            continue
        if key.lower() in fallback_keys_lower or key.lower().replace(" ", "") == preferred_key.lower().replace(" ", ""):
            return v
    return None


def get_existing_attendance_times(user_id, date_str, card_no=None, name=None):
    """
    Get existing check-in and check-out times from Logs table for this user/date.
    Returns (existing_ci_iso or None, existing_co_iso or None).
    """
    ci_iso, co_iso = None, None
    logs_rec = _find_logs_record(user_id, date_str, card_no=card_no, name=name)
    if logs_rec and logs_rec.get("fields"):
        f = logs_rec["fields"] or {}
        ci_iso = _get_field_value(f, FIELDS_LOGS["Check-in Time"])
        co_iso = _get_field_value(f, FIELDS_LOGS["Check-out Time"])
    if DEBUG_LOOKUP and (user_id is not None or name or card_no):
        who = "UserID=%s" % user_id if (user_id is not None and int(user_id or 0) != 0) else (name or card_no or str(user_id))
        status = "found CI=%s" % ("Yes" if ci_iso else "No")
        if not ci_iso and logs_rec:
            status += " (row found but no Check-in Time value - check Airtable field name)"
        print("  Lookup %s | %s | %s" % (str(who)[:35], date_str, status))
    return (ci_iso or None, co_iso or None)


def _get_office_tz():
    """Return timezone for office hours (8am–5pm). Uses ZoneInfo if available; on Windows
    ZoneInfo('Asia/Manila') often fails — fall back to UTC+8 (Philippines)."""
    if not OFFICE_TZ:
        return None
    if ZoneInfo is not None:
        try:
            return ZoneInfo(OFFICE_TZ)
        except Exception:
            pass
    return timezone(timedelta(hours=OFFICE_TZ_FALLBACK_UTC_OFFSET_HOURS))


def _compute_work_hours(check_in_dt, check_out_dt):
    """
    Compute work hours that count toward Total Work Time.
    - Only time between 8am and 5pm (office hours) counts.
    - Check-in before 8am: count from 8am (hours before 8am do not count).
    - Check-out after 5pm: count until 5pm (hours after 5pm do not count).
    - Result is capped at 8h per day (8am–5pm with 1h lunch).
    """
    if not check_in_dt or not check_out_dt or check_out_dt <= check_in_dt:
        return 0.0

    office_tz = _get_office_tz()
    if office_tz is not None:
        ci_local = check_in_dt.astimezone(office_tz)
        co_local = check_out_dt.astimezone(office_tz)
        d = ci_local.date()
        office_start = datetime(d.year, d.month, d.day, OFFICE_START_HOUR, 0, 0, tzinfo=office_tz)
        office_end = datetime(d.year, d.month, d.day, OFFICE_END_HOUR, 0, 0, tzinfo=office_tz)
        effective_start = max(ci_local, office_start)
        effective_end = min(co_local, office_end)
        if effective_end <= effective_start:
            return 0.0
        raw_hours = (effective_end - effective_start).total_seconds() / 3600.0
    else:
        raw_hours = (check_out_dt - check_in_dt).total_seconds() / 3600.0

    return round(min(8.0, raw_hours), 2)


def upsert_logs_row(full_fields):
    """
    Upsert one attendance row into Logs table for (UserID, Attendance Date).
    Called on every auth: one row per user per day is created/updated.
    - First auth of the day: create row with check-in time, check-out blank, Total Work Time 0.
    - Later auths: update same row with check-out time (and recompute Total Work Time).
    - Keeps earliest Check-in and latest Check-out; work hours use 8am–5pm window, 8h cap.
    """
    user_id = full_fields.get("UserID") or 0
    date_str = full_fields.get("Attendance Date") or ""
    new_ci = _parse_iso_datetime(full_fields.get("Check-in Time"))
    new_co = _parse_iso_datetime(full_fields.get("Check-out Time"))
    if not new_ci:
        return full_fields

    card_no = (full_fields.get("CardNo") or "").strip()
    name = (full_fields.get("Name") or "").strip()
    existing = _find_logs_record(user_id, date_str, card_no=card_no, name=name)

    if existing and existing.get("fields"):
        fields = existing.get("fields", {})
        existing_ci = _parse_iso_datetime(fields.get(FIELDS_LOGS["Check-in Time"]))
        existing_co = _parse_iso_datetime(fields.get(FIELDS_LOGS["Check-out Time"]))
    else:
        existing_ci, existing_co = None, None

    check_in_dt = existing_ci or new_ci
    if new_ci and (not check_in_dt or new_ci < check_in_dt):
        check_in_dt = new_ci

    if new_co and new_co > new_ci:
        check_out_dt = max(existing_co, new_co) if existing_co else new_co
    else:
        check_out_dt = None 

    if check_out_dt and check_out_dt > check_in_dt:
        work_hours = _compute_work_hours(check_in_dt, check_out_dt)
    else:
        work_hours = 0.0

    if existing and existing.get("fields"):
        existing_dm = existing["fields"].get(FIELDS_LOGS["Detection Mode"])
    else:
        existing_dm = []
    if isinstance(existing_dm, str):
        existing_dm = [existing_dm] if existing_dm else []
    if not isinstance(existing_dm, list):
        existing_dm = []
    new_dm = full_fields.get("Detection Mode") or []
    if isinstance(new_dm, str):
        new_dm = [new_dm] if new_dm else []
    merged_dm = sorted(set(existing_dm) | set(new_dm), key=lambda x: DETECTION_MODE_OPTIONS.index(x) if x in DETECTION_MODE_OPTIONS else 99)

    updated = dict(full_fields)
    updated["Check-in Time"] = _format_iso_datetime(check_in_dt)
    updated["Total Work Time"] = work_hours
    updated["Detection Mode"] = merged_dm
    if check_out_dt and check_out_dt > check_in_dt:
        updated["Check-out Time"] = _format_iso_datetime(check_out_dt)
    else:
        updated["Check-out Time"] = "" 

    airtable_fields = apply_table_columns(updated, FIELDS_LOGS)

    if existing:
        url = f"https://api.airtable.com/v0/{AIRTABLE_BASE_ID}/{TABLE_LOGS}/{existing['id']}"
        resp = requests.patch(url, json={"fields": airtable_fields}, headers={
            "Authorization": f"Bearer {AIRTABLE_API_KEY}",
            "Content-Type": "application/json",
        }, timeout=30)
        if not resp.ok:
            print("Airtable error (Logs update):", resp.status_code, resp.text)
            resp.raise_for_status()
        return updated

    push_to_table(TABLE_LOGS, airtable_fields)
    return updated


# =========================
# MAIN LOGIC
# =========================
def group_records_by_attendance_day(record_list):
    """
    Group (recno, rec) by (user_key, date). Then merge groups that are the same person
    on the same day (same date + same normalized name) so we never create two check-ins
    when the device sends different UserID/CardNo for the same person.
    Returns list of (max_recno, date_str, user_key, items).
    """
    from collections import defaultdict
    groups = defaultdict(list)
    for recno, rec in record_list:
        ts_str = rec.get("CreateTime", "")
        if not ts_str:
            continue
        try:
            ts = int(ts_str)
        except ValueError:
            continue
        date_str = unix_to_date_str(ts)
        user_id = to_int(rec.get("UserID"))
        card_no = (rec.get("CardNo") or "").strip()
        user_key = (user_id if user_id is not None else None, card_no or str(user_id))
        key = (user_key, date_str)
        groups[key].append((recno, ts, rec))

    out = []
    for (user_key, date_str), items in groups.items():
        items.sort(key=lambda x: x[1])
        max_recno = max(r[0] for r in items)
        out.append((max_recno, date_str, user_key, items))

    def merge_key(max_recno, date_str, user_key, items):
        uid = user_key[0] if user_key else None
        if uid is not None and (uid == 0 or uid == "0"):
            uid = 0
        if uid is not None and int(uid) != 0:
            return (date_str, int(uid))  
        rec = items[0][2] if items else {}
        card = (rec.get("CardNo") or "").strip() or ((rec.get("CardName") or "").strip().lower())
        return (date_str, 0, card or id(items))

    merged = {}
    for max_recno, date_str, user_key, items in out:
        key = merge_key(max_recno, date_str, user_key, items)
        if key in merged:
            old_recno, old_date, old_uk, old_items = merged[key]
            combined = old_items + items
            combined.sort(key=lambda x: x[1])
            better_uk = old_uk if (old_uk[0] and int(old_uk[0] or 0) != 0) or (old_uk[1] and str(old_uk[1]) != "0") else user_key
            if (user_key[0] and int(user_key[0] or 0) != 0) or (user_key[1] and str(user_key[1]) != "0"):
                better_uk = user_key
            merged[key] = (max(old_recno, max_recno), old_date, better_uk, combined)
        else:
            merged[key] = (max_recno, date_str, user_key, items)

    return list(merged.values())


def detection_methods_from_rec(rec):
    """
    Get detection method(s) from one Dahua record. Returns a list so one event can be
    Face+Card etc. FaceIndex=1 -> Face; Method/VerifyType: 0=Password, 1=Card, 2=Face.
    Some devices use bitmask (e.g. 3 = Card+Face). Also supports string values and extra field names.
    """
    methods = set()
    # FaceIndex=1 means face was used
    face_index = (rec.get("FaceIndex") or "0").strip()
    if face_index == "1":
        methods.add("Face")
    # Try all known field names for verify type (different firmware use different names)
    raw = (
        rec.get("Method") or rec.get("VerifyType") or rec.get("AuthType")
        or rec.get("VerifyMode") or rec.get("DetectionType") or rec.get("EventType") or rec.get("Type") or ""
    )
    s = str(raw).strip().lower() if raw else ""
    # String values (e.g. "face", "card", "2")
    if s in ("face", "2"):
        methods.add("Face")
    elif s in ("card", "1"):
        methods.add("Card")
    elif s in ("password", "0"):
        methods.add("Password")
    # Numeric: bitmask (1=Card, 2=Face, 4=Password) or single value 0/1/2
    if not s or s.isdigit():
        try:
            val = int(s) if s else None
            if val is None and raw is not None:
                val = int(str(raw).strip()) if str(raw).strip() else None
        except (ValueError, TypeError):
            val = None
        if val is not None:
            if val & 1:
                methods.add("Card")
            if val & 2:
                methods.add("Face")
            if val & 4:
                methods.add("Password")
            if not methods and 0 <= val <= 2:
                if val == 0:
                    methods.add("Password")
                elif val == 1:
                    methods.add("Card")
                elif val == 2:
                    methods.add("Face")
    # Device supports face+card: show both when we can't tell (valid auth = either method)
    if not methods:
        methods = {"Face", "Card"}
    # Always include Face since facial detection is used every time
    methods.add("Face")
    return sorted(methods, key=lambda x: DETECTION_MODE_OPTIONS.index(x) if x in DETECTION_MODE_OPTIONS else 99)


def detection_modes_for_day(items):
    """Collect unique detection methods from all events for this user/day. For Airtable Multiple Select."""
    all_methods = set()
    for _recno, _ts, rec in items:
        for m in detection_methods_from_rec(rec):
            all_methods.add(m)
    # Always include Face since facial detection is used every time
    all_methods.add("Face")
    return sorted(all_methods, key=lambda x: DETECTION_MODE_OPTIONS.index(x) if x in DETECTION_MODE_OPTIONS else 99)


def build_full_fields(date_str, user_id, name, card_no, check_in_iso, check_out_iso, total_hours, detection_mode):
    """Build full field dict (internal keys). detection_mode: list for Multiple Select, e.g. ['Face', 'Card']."""
    if isinstance(detection_mode, str):
        detection_mode = [detection_mode] if detection_mode else ["Face", "Card"]
    if not detection_mode:
        detection_mode = ["Face", "Card"]
    # Always ensure Face is included since facial detection is used every time
    if isinstance(detection_mode, list):
        detection_mode = list(set(detection_mode + ["Face"]))
    return {
        "UserID": user_id or 0,
        "Name": name or "",
        "Attendance Date": date_str,
        "CardNo": card_no or "",
        "Check-in Time": check_in_iso or "",
        "Check-out Time": check_out_iso or "",
        "Total Work Time": total_hours,
        "Detection Mode": detection_mode,
    }


def apply_table_columns(full_fields, column_map):
    """Return only keys that exist in column_map, with Airtable column names. Send null for blank date fields so Airtable clears them."""
    result = {}
    date_fields = {"Check-in Time", "Check-out Time", "Time"}  
    multi_select_fields = {"Detection Mode"}  
    for k in column_map:
        if k in full_fields:
            v = full_fields[k]
            if (v == "" or v is None) and k in date_fields:
                result[column_map[k]] = None
                continue
            if k in multi_select_fields and isinstance(v, str):
                v = [v] if v else []
            result[column_map[k]] = v
    return result


def main():
    fetch_only = "--fetch-only" in sys.argv or "-n" in sys.argv

    print("Fetching logs from Dahua device...")
    try:
        raw = fetch_logs()
    except Exception as e:
        print("Dahua fetch failed:", e)
        print("Check: device IP, network, username/password.")
        sys.exit(1)
    records = parse_dahua_response(raw)
    if DEBUG_LOOKUP and records:
        first_idx = min(records.keys(), key=lambda x: int(x))
        sample = records[first_idx]
        verify_keys = [k for k in sample if "ethod" in k or "erif" in k or "ace" in k or "ype" in k or "ode" in k or "vent" in k]
        print("DEBUG: First record keys (verify-related):", {k: sample.get(k) for k in verify_keys} if verify_keys else list(sample.keys())[:15])
    last_recno = load_last_recno()
    new_record_list = [] 

    for idx in sorted(records.keys(), key=lambda x: int(x)):
        rec = records[idx]
        recno = int(rec.get("RecNo", 0))
        if recno <= last_recno:
            continue
        status = rec.get("Status", "")
        error_code = rec.get("ErrorCode", "")
        if str(status) != "1" or str(error_code) != "0":
            continue
        new_record_list.append((recno, rec))

    if not new_record_list:
        print(f"No new logs (last RecNo: {last_recno}).")
        return

    groups = group_records_by_attendance_day(new_record_list)
    new_logs = [] 

    for max_recno, date_str, user_key, items in groups:
        first_rec = items[0][2]
        check_in_recno = items[0][0]
        user_id = to_int(first_rec.get("UserID")) or 0
        # Skip records with no user id or user id 0 — do not send to Airtable
        if user_id is None or user_id == 0:
            save_last_recno(max_recno)
            continue
        name = (first_rec.get("CardName") or "").strip()
        card_no = (first_rec.get("CardNo") or "").strip()
        detection_mode = detection_modes_for_day(items)
        times = [x[1] for x in items]
        batch_ci_ts = min(times)
        batch_co_ts = max(times)
        # Merge with existing Airtable data so e.g. second run (only 5pm event) still has 8am check-in
        existing_ci_iso, existing_co_iso = get_existing_attendance_times(user_id, date_str, card_no=card_no, name=name)
        existing_ci_ts = _parse_iso_datetime(existing_ci_iso).timestamp() if existing_ci_iso and _parse_iso_datetime(existing_ci_iso) else None
        existing_co_ts = _parse_iso_datetime(existing_co_iso).timestamp() if existing_co_iso and _parse_iso_datetime(existing_co_iso) else None
        merged_ci_ts = min(batch_ci_ts, existing_ci_ts) if existing_ci_ts is not None else batch_ci_ts
        merged_co_ts = max(batch_co_ts, existing_co_ts) if existing_co_ts is not None else batch_co_ts
        check_in_iso = unix_to_iso(str(int(merged_ci_ts)))
        check_out_iso = unix_to_iso(str(int(merged_co_ts)))
        total_hours = (merged_co_ts - merged_ci_ts) / 3600.0 if merged_co_ts > merged_ci_ts else None
        total_work = round(total_hours, 2) if total_hours is not None else 0
        full_fields = build_full_fields(
            date_str, user_id, name, card_no, check_in_iso, check_out_iso, total_work, detection_mode
        )
        # Only update Logs and Check-out when user has both check-in and check-out (at least 2 auths)
        has_both = merged_co_ts > merged_ci_ts
        # Only treat as "check-in" (create Check-in row) when this is the first auth of the day
        is_first_auth = existing_ci_iso is None
        new_logs.append((max_recno, full_fields, has_both, is_first_auth))

    print(f"Found {len(new_record_list)} new event(s) -> {len(new_logs)} attendance row(s) (last RecNo was {last_recno}).")

    if not new_logs:
        print("No attendance rows to push (all skipped or invalid UserID).")
        return

    if fetch_only:
        print("--fetch-only: not pushing to Airtable. Sample (Logs):")
        print(json.dumps(apply_table_columns(new_logs[0][1], FIELDS_LOGS), indent=2))
        print("...")
        return

    try:
        with open(LOCAL_LOGS_FILE, "w", encoding="utf-8") as f:
            json.dump([apply_table_columns(f, FIELDS_LOGS) for _, f, _, _ in new_logs], f, indent=2)
        print(f"Backup saved to {LOCAL_LOGS_FILE}")
    except OSError:
        pass

    pushed = 0
    users_seen = set() 
    for recno, full_fields, has_both, is_first_auth in new_logs:
        try:
            print("Pushing:", full_fields.get("Name", ""), full_fields.get("Attendance Date", ""), "(check-in + check-out)" if has_both else "(check-in only)", "...")
            if PUSH_TO_LOGS:
                full_fields = upsert_logs_row(full_fields)
                time.sleep(0.15)
            user_key = (full_fields.get("UserID"), full_fields.get("Name"), full_fields.get("CardNo"))
            if PUSH_TO_USERS and user_key not in users_seen:
                users_seen.add(user_key)
            save_last_recno(recno)
            pushed += 1
        except requests.exceptions.HTTPError:
            print("Stopping: Airtable rejected record. Fix field names or types and run again.")
            print("Next run will retry from RecNo", recno)
            sys.exit(1)

    if PUSH_TO_USERS and users_seen:
        for (uid, name, card_no) in users_seen:
            try:
                if user_exists_in_users_table(uid, card_no):
                    continue
                user_fields = apply_table_columns(
                    {"UserID": uid, "Name": name or "", "CardNo": card_no or ""},
                    FIELDS_USERS,
                )
                push_to_table(TABLE_USERS, user_fields)
                time.sleep(0.15)
            except requests.exceptions.HTTPError as e:
                print("Users table error (continuing):", e)

    print(f"Done. Pushed {pushed} attendance row(s). Users: {len(users_seen)}. Last RecNo: {recno}.")

# =========================
# ENTRY POINT
# =========================
if __name__ == "__main__":
    run_once = "--once" in sys.argv or "-1" in sys.argv
    if run_once:
        main()
    else:
        print(f"Running continuously: fetch every {POLL_INTERVAL_MINUTES} min. (Use --once to run once and exit.)")
        while True:
            try:
                main()
            except KeyboardInterrupt:
                print("Stopped by user.")
                break
            except Exception as e:
                print("Run error:", e)
            print(f"Next run in {POLL_INTERVAL_MINUTES} min...")
            time.sleep(POLL_INTERVAL_MINUTES * 60)
