# Airtable tables and columns (multi-table)

The script can push to **4 tables** in the same base. Turn each on/off with `PUSH_TO_LOGS`, `PUSH_TO_CHECK_IN`, `PUSH_TO_CHECK_OUT`, `PUSH_TO_USERS` at the top of the script.

---

## 1. Logs (one row per attendance day, full record)

| Column name       | Type in Airtable     |
|-------------------|----------------------|
| UserID            | Number               |
| Name              | Single line text     |
| Attendance Date   | Date                 |
| CardNo            | Single line text     |
| Check-in Time     | Date (include time)  |
| Check-out Time    | Date (include time)  |
| Total Work Time   | Number               |
| Detection Mode    | Single line text     |
| Check-in Picture  | URL or Single line text |

---

## 2. Check-in (one row per attendance day, check-in focus)

| Column name       | Type in Airtable     |
|-------------------|----------------------|
| UserID            | Number               |
| Name              | Single line text     |
| Attendance Date   | Date                 |
| CardNo            | Single line text     |
| Check-in Time     | Date (include time)  |
| Detection Mode    | Single line text     |
| Check-in Picture  | URL or Single line text |

---

## 3. Check-out (one row per attendance day when check-out exists)

| Column name       | Type in Airtable     |
|-------------------|----------------------|
| UserID            | Number               |
| Name              | Single line text     |
| Attendance Date   | Date                 |
| CardNo            | Single line text     |
| Check-out Time    | Date (include time)  |

*Rows are only created when there is a check-out time (more than one swipe that day).*

---

## 4. Users (one row per person)

| Column name | Type in Airtable |
|-------------|------------------|
| UserID      | Number           |
| Name        | Single line text |
| CardNo      | Single line text |

*New users from each run are appended. You may get duplicate UserID across runs; use Airtable dedupe or a unique constraint if you need one row per person.*

---

Rename tables in the script with `TABLE_LOGS`, `TABLE_CHECK_IN`, `TABLE_CHECK_OUT`, `TABLE_USERS`. Column names are in `FIELDS_LOGS`, `FIELDS_CHECK_IN`, `FIELDS_CHECK_OUT`, `FIELDS_USERS` — change the **values** (right side) to match your Airtable column names.

---

## Check-in picture / live snapshot

- **Check-in Picture** is the URL of the snapshot the device captured at check-in (face/card photo).
- The script uses the **URL** field from the Dahua access log when the device fills it (some do, some leave it empty). If the log URL is relative (e.g. `/path/to/image.jpg`), the script turns it into a full URL using the device IP.
- If your device never fills **URL**, you can try a **snapshot-by-RecNo** URL. In the script set `SNAPSHOT_URL_TEMPLATE` to a URL with a `{RecNo}` placeholder (e.g. `http://192.168.0.108/cgi-bin/...&RecNo={RecNo}`). The exact path depends on your model; check the device manual or Dahua integration docs.
- In Airtable use a **URL** field or **Single line text** for Check-in Picture. Airtable can show a clickable link; for inline images you’d need a formula or extension that renders the URL as an image.
