# How to run Dahua → Airtable automatically (backend)

The script does **not** push logs by itself until something runs it. You can either run it **once** manually, or set it up to run **automatically** in the background.

---

## Option A: Run once manually

Every time you want to sync logs, open a terminal and run:

```powershell
cd "C:\Users\Knudcen De Villa\Desktop\dahua_logs"
python dahua_to_airtable.py --once
```

---

## Option B: Run continuously in a terminal (good for testing)

The script can loop forever and fetch every few minutes. Keep a terminal open:

```powershell
cd "C:\Users\Knudcen De Villa\Desktop\dahua_logs"
python dahua_to_airtable.py
```

- It will fetch from Dahua and push to Airtable, then wait **5 minutes** (set `POLL_INTERVAL_MINUTES` in the script to change this), then repeat.
- Press **Ctrl+C** to stop.
- If you close the terminal, it stops. For a real “backend” that keeps running after you log off, use Option C or D.

---

## Option C: Windows Task Scheduler (recommended for “backend”)

This runs the script every X minutes even when you’re not using the PC.

1. Open **Task Scheduler** (search “Task Scheduler” in Start).
2. **Create Basic Task** (or Create Task).
3. **Name:** e.g. `Dahua logs to Airtable`.
4. **Trigger:** Daily (or At startup if you prefer). Then set **Repeat task every** → **5 minutes** (or 10), for a duration of **Indefinitely**.
5. **Action:** Start a program.
   - **Program:** `python` (or full path, e.g. `C:\Users\Knudcen De Villa\AppData\Local\Programs\Python\Python312\python.exe`).
   - **Arguments:** `dahua_to_airtable.py --once`
   - **Start in:** `C:\Users\Knudcen De Villa\Desktop\dahua_logs`
6. Finish. Optionally: **Properties** → **General** → check **Run whether user is logged on or not** and **Run with highest privileges** if you need it to run when no one is logged in.

Result: every 5 minutes (or whatever you set) the script runs once, fetches new logs, and pushes to Airtable. No need to run the `.py` file yourself.

---

## Option D: Run as a background process (no Task Scheduler)

If you prefer one long-running Python process instead of Task Scheduler:

1. Open PowerShell and run:
   ```powershell
   cd "C:\Users\Knudcen De Villa\Desktop\dahua_logs"
   python dahua_to_airtable.py
   ```
2. Minimize the window; it will keep running and syncing every 5 minutes.
3. To run without keeping a window open, use **pythonw** (no console window):
   ```powershell
   Start-Process pythonw -ArgumentList "dahua_to_airtable.py" -WorkingDirectory "C:\Users\Knudcen De Villa\Desktop\dahua_logs" -WindowStyle Hidden
   ```
   The process keeps running in the background until you restart or kill it.

---

## Summary

| Goal                         | What to do                                              |
|-----------------------------|---------------------------------------------------------|
| Sync once, manually         | `python dahua_to_airtable.py --once`                   |
| Sync every 5 min, test      | `python dahua_to_airtable.py` (leave terminal open)     |
| **Proper backend (automatic)** | **Task Scheduler**: run `python dahua_to_airtable.py --once` every 5–10 min in `dahua_logs` folder |

Change `POLL_INTERVAL_MINUTES` in the script if you use Option B or D and want a different interval.
